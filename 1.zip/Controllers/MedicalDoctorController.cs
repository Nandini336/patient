﻿using DoctorAppointmentSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DoctorAppointmentSystem.Controllers
{
    public class MedicalDoctorController : Controller
    {
        dbDoctorAppointmentEntities db = new dbDoctorAppointmentEntities();

        public ActionResult Departments()
        {
            var model = (from u in db.tblDepartmentDoctors
                         select u).ToList();

            return View(model);
        }

    }
}