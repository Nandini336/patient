﻿using DoctorAppointmentSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Windows.Forms;

namespace DoctorAppointmentSystem.Controllers
{
    public class ReceptionController : Controller
    {
        dbDoctorAppointmentEntities db = new dbDoctorAppointmentEntities();
        dbDoctorAppointmentEntities1 db1 = new dbDoctorAppointmentEntities1();
        [HttpGet]
        public ActionResult ReceptionRegister()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ReceptionRegister(tblPatientOfficial1 patientDetail)
        {
            string MESSAGE = string.Empty;
            if (ModelState.IsValid)
            {
                db1.sp_ReceptionistPatient1(patientDetail.iPatientId, patientDetail.cFirstName, patientDetail.cLastName, patientDetail.cDepartment, patientDetail.cDoctorName, patientDetail.cAge, patientDetail.cAddress, patientDetail.cMobileNumber, patientDetail.dAppointmentDate, patientDetail.cAppointmentTime,patientDetail.cPatientType);
                //db.tblPatientDetails.Add(tblPatientDetail);
                db1.SaveChanges();
                ViewBag.message = "Registration Successfull";
                MESSAGE = "Registration Successfull";
                System.Windows.Forms.MessageBox.Show(MESSAGE);
                return RedirectToAction("ReceptionistHome", "Reception");
            }

            return View(patientDetail);
        }

        public ActionResult ReceptionistHome()
        {
            if (Session["UserId"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("UserLogin","Login");
            }
        }

        public ActionResult DepartmentDoctor()
        {
            return View(db.tblDepartmentDoctors.ToList());
        }

        public ActionResult Patients()
        {
            return View(db1.tblPatientOfficial1.ToList());
        }

        public ActionResult GenerateBill()
        {
            var model = (from u in db1.tblPatientOfficial1
                         select u);

            return View(model);
        }


        public ActionResult EditBill(int? id)
        {
            var model = (from u in db1.tblPatientOfficial1
                         where u.iPatientId.Equals((int)id)
                         select u).FirstOrDefault();

            return View(model);
        }

        [HttpPost]
        public ActionResult EditBill(tblPatientOfficial1 patient)
        {
            if (ModelState.IsValid)
            {
                db1.sp_Dues1(patient.iPatientId, patient.cDues);
                db.SaveChanges();
                MessageBox.Show("Bill added successfully.....!!!");
                return RedirectToAction("ReceptionistHome", "Reception");
            }
            return View();
        }

        public ActionResult ViewBills()
        {
            var m = (from u in db1.tblPatientOfficial1
                     where u.cDues != "No Dues"
                     select u);

            return View(m);
        }

        public ActionResult LogOut()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }
    }
}